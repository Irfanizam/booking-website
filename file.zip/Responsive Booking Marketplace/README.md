
  # Responsive Booking Marketplace

  This is a code bundle for Responsive Booking Marketplace. The original project is available at https://www.figma.com/design/ERTB8FMjjy0ibYYoZFr6nF/Responsive-Booking-Marketplace.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  